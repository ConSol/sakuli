# Headless Sakuli checks on Windows

To be done