The external libs can be found under 
[ConSol Labs - Sakui - dev_stuff](http://labs.consol.de/sakuli/dev_stuff/ext_libs/).